# core-vfx

## 0.0.3

### Patch Changes

- 9e350df: Move more logic that was in r3f-vfx into core-vfx

## 0.0.2

### Patch Changes

- f719588: Split useVFXStore into core-store and react-store

## 0.0.1

### Patch Changes

- 26a4a91: Initialize changesets, add TS and tsup
